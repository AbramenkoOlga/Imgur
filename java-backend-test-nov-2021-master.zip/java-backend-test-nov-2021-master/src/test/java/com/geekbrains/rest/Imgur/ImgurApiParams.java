package com.geekbrains.rest.Imgur;

public class ImgurApiParams {
    public static String TOKEN = "6c153b498817b6dacf1673167033bcbb64e236ec";
    public static String API_URL = "https://api.imgur.com";
    public static String API_VERSION = "3";
}
