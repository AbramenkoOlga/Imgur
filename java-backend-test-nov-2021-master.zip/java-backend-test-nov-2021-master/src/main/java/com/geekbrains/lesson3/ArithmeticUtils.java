package com.geekbrains.lesson3;

public class ArithmeticUtils {

    public static int sum(int x, int y) {
        return x + y;
    }

}
